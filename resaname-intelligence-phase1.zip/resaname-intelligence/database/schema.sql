CREATE TABLE IF NOT EXISTS editorial_users (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 username VARCHAR(80) NOT NULL UNIQUE,
 password_hash VARCHAR(255) NOT NULL,
 display_name VARCHAR(160) NOT NULL,
 role ENUM('editor','admin') NOT NULL DEFAULT 'editor',
 is_active TINYINT(1) NOT NULL DEFAULT 1,
 last_login_at DATETIME NULL,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS editorial_documents (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 source_table VARCHAR(64) NOT NULL,
 source_id VARCHAR(64) NOT NULL,
 title VARCHAR(500) NOT NULL,
 source_status VARCHAR(40) NULL,
 source_updated_at DATETIME NULL,
 original_json LONGTEXT NOT NULL,
 original_hash CHAR(64) NOT NULL,
 current_json LONGTEXT NOT NULL,
 current_hash CHAR(64) NOT NULL,
 workflow_status ENUM('imported','queued','processing','draft_ready','review','approved','rejected','published','error') NOT NULL DEFAULT 'imported',
 quality_score TINYINT UNSIGNED NULL,
 created_at DATETIME NOT NULL,
 updated_at DATETIME NOT NULL,
 UNIQUE KEY uq_source (source_table,source_id),
 KEY idx_workflow (workflow_status,updated_at),
 KEY idx_title (title(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS editorial_revisions (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 document_id BIGINT UNSIGNED NOT NULL,
 revision_type ENUM('original','ai_draft','editor_edit','approved') NOT NULL,
 content_json LONGTEXT NOT NULL,
 content_hash CHAR(64) NOT NULL,
 created_by BIGINT UNSIGNED NULL,
 note TEXT NULL,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 KEY idx_doc (document_id,created_at),
 CONSTRAINT fk_revision_doc FOREIGN KEY (document_id) REFERENCES editorial_documents(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS editorial_jobs (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 document_id BIGINT UNSIGNED NOT NULL,
 job_type VARCHAR(40) NOT NULL,
 status ENUM('pending','running','done','failed') NOT NULL DEFAULT 'pending',
 attempts TINYINT UNSIGNED NOT NULL DEFAULT 0,
 available_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 locked_at DATETIME NULL,
 last_error TEXT NULL,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 KEY idx_queue (status,available_at),
 CONSTRAINT fk_job_doc FOREIGN KEY (document_id) REFERENCES editorial_documents(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS editorial_sources (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 document_id BIGINT UNSIGNED NOT NULL,
 title VARCHAR(1000) NOT NULL,
 url VARCHAR(2000) NULL,
 doi VARCHAR(255) NULL,
 publisher VARCHAR(500) NULL,
 source_type VARCHAR(40) NULL,
 verification_status ENUM('unverified','verified','rejected') NOT NULL DEFAULT 'unverified',
 evidence_note TEXT NULL,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 KEY idx_source_doc (document_id),
 CONSTRAINT fk_source_doc FOREIGN KEY (document_id) REFERENCES editorial_documents(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS editorial_reviews (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 document_id BIGINT UNSIGNED NOT NULL,
 editor_id BIGINT UNSIGNED NOT NULL,
 decision ENUM('approved','rejected','needs_changes') NOT NULL,
 note TEXT NULL,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 KEY idx_review_doc (document_id,created_at),
 CONSTRAINT fk_review_doc FOREIGN KEY (document_id) REFERENCES editorial_documents(id) ON DELETE CASCADE,
 CONSTRAINT fk_review_user FOREIGN KEY (editor_id) REFERENCES editorial_users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS editorial_logs (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 level VARCHAR(20) NOT NULL,
 event VARCHAR(100) NOT NULL,
 context_json LONGTEXT NULL,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 KEY idx_log_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
