<?php
require dirname(__DIR__).'/bootstrap.php';
\Resaname\Auth::requireLogin();
$db=\Resaname\Db::editorial();
$id=(int)($_GET['id']??0);
$q=$db->prepare("SELECT * FROM editorial_documents WHERE id=?"); $q->execute([$id]); $doc=$q->fetch();
if(!$doc){http_response_code(404);exit('محتوا پیدا نشد');}
$original=json_decode($doc['original_json'],true) ?: [];
$current=json_decode($doc['current_json'],true) ?: [];
function h($v){return \Resaname\Support::e((string)$v);}
?>
<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title><?=h($doc['title'])?></title><link rel="stylesheet" href="/style.css"></head><body><header><a href="/">← بازگشت به فهرست</a><strong>بررسی محتوا</strong></header><main><h1><?=h($doc['title'])?></h1><p>جدول: <?=h($doc['source_table'])?> | شناسه: <?=h($doc['source_id'])?> | وضعیت: <?=h($doc['workflow_status'])?></p><div class="columns"><section><h2>نسخه اولیه</h2><pre><?=h(json_encode($original,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE))?></pre></section><section><h2>نسخه جاری</h2><pre><?=h(json_encode($current,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE))?></pre></section></div><p class="notice">در این نسخه، انتشار و ویرایش مستقیم غیرفعال است. ابتدا نگاشت فیلدها و قرارداد API باید تأیید شود.</p></main></body></html>
