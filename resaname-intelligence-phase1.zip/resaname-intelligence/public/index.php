<?php
require dirname(__DIR__).'/bootstrap.php';
\Resaname\Auth::requireLogin();
$db=\Resaname\Db::editorial();
$counts=$db->query("SELECT workflow_status,COUNT(*) c FROM editorial_documents GROUP BY workflow_status")->fetchAll();
$rows=$db->query("SELECT id,source_table,source_id,title,workflow_status,quality_score,updated_at FROM editorial_documents ORDER BY updated_at DESC LIMIT 50")->fetchAll();
function h($v){return \Resaname\Support::e((string)$v);}
?>
<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>میز سردبیری رسانامه</title><link rel="stylesheet" href="/style.css"></head><body>
<header><strong>رسانامه | کارخانه هوشمندسازی</strong><span><?=h($_SESSION['editor_user']['display_name'])?> · <a href="/logout.php">خروج</a></span></header>
<main><h1>میز سردبیری</h1><section class="stats"><?php foreach($counts as $c): ?><div><b><?=h($c['c'])?></b><span><?=h($c['workflow_status'])?></span></div><?php endforeach; ?></section>
<h2>آخرین محتواها</h2><table><thead><tr><th>عنوان</th><th>نوع</th><th>شناسه</th><th>وضعیت</th><th>امتیاز</th><th></th></tr></thead><tbody>
<?php foreach($rows as $r): ?><tr><td><?=h($r['title'])?></td><td><?=h($r['source_table'])?></td><td><?=h($r['source_id'])?></td><td><?=h($r['workflow_status'])?></td><td><?=h($r['quality_score']??'—')?></td><td><a href="/document.php?id=<?=(int)$r['id']?>">بررسی</a></td></tr><?php endforeach; ?>
</tbody></table></main></body></html>
