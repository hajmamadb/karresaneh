<?php
namespace Resaname;
final class Support {
    public static function e(?string $s): string { return htmlspecialchars($s ?? '', ENT_QUOTES|ENT_SUBSTITUTE, 'UTF-8'); }
    public static function log(string $message, array $context=[]): void {
        $line='['.date('c').'] '.$message.' '.json_encode($context,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES).PHP_EOL;
        $dir=dirname(__DIR__).'/storage/logs';
        if (!is_dir($dir)) mkdir($dir,0700,true);
        file_put_contents($dir.'/app.log',$line,FILE_APPEND|LOCK_EX);
    }
    public static function csrf(): string {
        if (empty($_SESSION['_csrf'])) $_SESSION['_csrf']=bin2hex(random_bytes(32));
        return $_SESSION['_csrf'];
    }
    public static function verifyCsrf(): void {
        $sent=$_POST['_csrf'] ?? '';
        if (!is_string($sent) || !hash_equals(self::csrf(),$sent)) {
            http_response_code(419); exit('درخواست نامعتبر است.');
        }
    }
}
